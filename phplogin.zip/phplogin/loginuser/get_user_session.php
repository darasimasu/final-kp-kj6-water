<?php
session_start();
header("Access-Control-Allow-Origin: *"); // Tambahkan ini untuk mengatasi CORS
header("Content-Type: application/json");

if (isset($_SESSION["user_data"])) {
    $user_data = json_decode($_SESSION["user_data"], true);
    echo json_encode(["username" => $user_data["username"] ?? "USER"]);
} else {
    echo json_encode(["username" => "USER"]);
}
?>
