<?php
// Update the path below to your autoload.php
require_once 'C:/xampp/htdocs/phplogin/vendor/autoload.php'; // Sesuaikan path ke autoload.php Anda
use Twilio\Rest\Client;

// Koneksi ke database (gunakan kredensial database Anda)
$servername = "localhost";
$username = "root"; // Ganti dengan username MySQL Anda
$password = ""; // Ganti dengan password MySQL Anda
$dbname = "database1"; // Nama database yang Anda gunakan

// Membuat koneksi ke MySQL
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Kode verifikasi acak 6 digit
function generateVerificationCode() {
    return str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
}

// Nomor yang diterima dari client
$data = json_decode(file_get_contents('php://input'), true);
$nomor_hp = $data['nomor_hp'];

if (!$nomor_hp) {
    echo json_encode(['success' => false, 'message' => 'Nomor handphone tidak valid!']);
    exit;
}

// Cek apakah nomor handphone sudah terdaftar
$query = "SELECT id FROM login_user WHERE nomor_hp = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $nomor_hp); // Binding parameter
$stmt->execute();
$stmt->store_result();

// Jika nomor tidak ditemukan
if ($stmt->num_rows == 0) {
    echo json_encode(['success' => false, 'message' => 'Maaf! Nomor tak terdaftar!']);
    $stmt->close();
    $conn->close();
    exit;
}

// Twilio credentials
$sid    = "AC6cbe378913c25c7c421decef37750d0d";
$token  = "d398dfc5925e87c1c10830fc2390c3cb";
$twilio = new Client($sid, $token);

// Generate verification code
$verification_code = generateVerificationCode();

// Kirim kode verifikasi melalui WhatsApp menggunakan Twilio
$message = $twilio->messages->create(
    "whatsapp:+62" . substr($nomor_hp, 1), // Format nomor tujuan dengan kode negara
    [
        "from" => "whatsapp:+14155238886", // Nomor Twilio WhatsApp
        "body" => "Kode verifikasi Anda adalah: $verification_code"
    ]
);

// Cek apakah pengiriman pesan berhasil
if ($message->sid) {
    // Simpan kode verifikasi ke dalam database
    $stmt = $conn->prepare("INSERT INTO verifications (nomor_hp, kode_verifikasi, created_at, expires_at) VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 21 HOUR))");
    $stmt->bind_param("ss", $nomor_hp, $verification_code); // Binding parameter
    $stmt->execute();

    // Cek apakah data berhasil disimpan
    if ($stmt->affected_rows > 0) {
        echo json_encode(['success' => true, 'message' => 'Kode verifikasi telah dikirim dan disimpan di database.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal menyimpan kode verifikasi ke database.']);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal mengirim kode verifikasi.']);
}

// Tutup koneksi database
$conn->close();
?>
