<?php
session_start();

// Pastikan user telah login
if (isset($_SESSION["user_data"])) {
    // Mendapatkan data user dari session
    $user_data = json_decode($_SESSION["user_data"], true);
    $username = $user_data["username"];

    // Koneksi ke database
    $servername = "localhost";
    $db_username = "root";
    $password = "";
    $db_name = "database1";

    $conn = new mysqli($servername, $db_username, $password, $db_name);

    if ($conn->connect_error) {
        die("Koneksi ke database gagal: " . $conn->connect_error);
    }

    // Menghapus data user dari database berdasarkan username
    $delete_query = "DELETE FROM login_user WHERE username = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("s", $username);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Data user berhasil dihapus dari database.";
    } else {
        echo "Gagal menghapus data user.";
    }

    // Hentikan sesi
    session_unset();
    session_destroy();

    // Redirect ke halaman login
    header("Location: index_login_user.php");
    exit();
} else {
    // Jika tidak ada sesi, redirect langsung
    header("Location: index_login_user.php");
    exit();
}
?>
