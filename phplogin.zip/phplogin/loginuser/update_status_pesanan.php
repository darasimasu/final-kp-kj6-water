<?php
// Koneksi ke database MySQL
$servername = "localhost";
$username = "root"; // Ganti dengan username MySQL Anda
$password = ""; // Ganti dengan password MySQL Anda
$dbname = "database1"; // Ganti dengan nama database Anda

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

// Mendapatkan nilai id dan status_pesanan dari parameter POST
$idPesanan = $_POST['id'];
$statusPesanan = $_POST['status_pesanan'];

// Update status_pesanan di database
$sql = "UPDATE daftar_pesanan SET status_pesanan='$statusPesanan' WHERE id='$idPesanan'";

if ($conn->query($sql) === TRUE) {
    echo "Status pesanan berhasil diperbarui.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
