<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Pesanan Sekarang</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Krona+One:wght@400&display=swap" />
    <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
    
    <style>

        @media only screen and (max-width: 600px) {
        /* Styles untuk perangkat dengan lebar maksimal 600px */
        body {
        background-size: cover; /* Atur background size agar menutupi layar */
        /* Tambahkan penyesuaian gaya lainnya */
        }
        }

        body {
            position: relative;
            background-image: url('https://i.ibb.co.com/3fJYPBS/background3.jpg');
            /* background-image: url('https://stsci-opo.org/STScI-01H5308GYAN46P3HX4PQ20HP31.png'); */
            background-size: 2550px 1685px;
            background-position: center;
            background-repeat: no-repeat;
            margin: 0;
            padding: 0;
            display: flex;
            /* overflow-x: visible; */
            overflow-x: hidden; /* Tambahkan ini untuk menghilangkan scroll horizontal */
        }

        .card-container {
            position: fixed;
            left: 0;
            top: 0;
            height: 930px;
            width: 133px;
            z-index: -2;
        }

        .card {
            width: 100%;
            height: 930px;
            background-color: #3887BE;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        .second-card {
            position: absolute;
            width: 1500px;
            height: 43px;
            z-index: -1;
            background-color: #143F6B;
        }

        .status-text {
            position: relative;
            font-size: 17px;
            color: white;
            margin-left: 20px;
            top: 27%; /* Sesuaikan nilai top sesuai kebutuhan (dalam persentase) */
            z-index: 5;
            width: 100%;
        }

        .status-text::before {
            position: absolute;
            content: "";
            top: -13px;
            left: -100px;
            width: 250px; /* Lebar background di sebelah kiri tulisan */
            height: 43px; /* Tinggi background di sebelah kiri tulisan */
            background-color: #143F6B; /* Warna background */
            z-index: -1;
        }

        #statusDepotData {
            position: relative;
            color: white;
            height: 100%;
            width: 100%;
            margin-left: 35%;
            margin-top: -0.5em;
            animation: slideFromRight 21s linear infinite;
            transform: translateX(100%);
        }

        @keyframes slideFromRight {
            from {
            transform: translateX(100%);
            }

            to {
            transform: translateX(-90%);
            }
        }

        ul {
            list-style-type: none;
            margin: 55px 0 0 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: flex-start;
            z-index: 5;
        }

        li span.material-symbols-outlined {
            font-size: 80px;
            color: #FEB139;
        }

        li {
            margin-inline-start: 35%;
            margin-top: -5%;
            margin-bottom: 21px;
            text-align: center;
            font-weight: bold;
            color: #FEB139;
        }

        #daftarAirGalon {
            width: 100%;
            height: 100%;
            position: relative;
        }

        #daftarAirGalon button {
            position: absolute;
            cursor: pointer;
            background-color: #143F6B;
            max-width: 100%; /* Mengganti width: 100% */
            width: 263px; /* Mengganti width: 263px */
            height: 45px; /* Mengganti width: 100% menjadi height: 45px */
            margin-top: 40px;
            margin-left: 77px;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            font-weight: bold;
            font-size: 18px;
            font-family: 'Krona One', sans-serif;
            transition: background-color 0.1s, color 0.1s;
            box-shadow: 0 0 5px rgba(255, 255, 255, 0.5), 0 5px 5px #d3d3d3; /* Tambahkan efek cahaya di pinggiran */
        }

        /* Menambahkan style untuk tombol ketika dihover */
        #daftarAirGalon button:hover {
            background-color: white;
            color: black;
        }

        /* Menambahkan style untuk tombol ketika diklik (active state) */
        #daftarAirGalon button:active {
            background-color: white;
            color: black;
        }

        #statusPesananSemua {
            position: absolute; /* Menggunakan position relative pada kontainer */
        }

        #statusPesananSemua button {
            position: absolute; /* Menggunakan position absolute pada tombol */
            cursor: pointer;
            background-color: #0D4C92;
            color: white;
            font-weight: bold;
            font-size: 15px;
            width: 175px;
            height: 43px;
            margin-top: 39px;
            margin-left: 1063px;
            font-family: 'Krona One', sans-serif;
            border: none; /* Menghilangkan border */
            outline: none; /* Menghilangkan tampilan outline saat tombol ditekan */
            border-radius: 9px; /* Menambahkan border radius */
        }

        /* Menambahkan style untuk tombol ketika dihover */
        #statusPesananSemua button:hover {
            background-color: white;
            color: black;
        }

        /* Menambahkan style untuk tombol ketika diklik (active state) */
        #statusPesananSemua button:active {
            background-color: white;
            color: black;
        }

        .white-card-container {
            position: absolute;
            margin-top: 125px;
            margin-left: 157px;
        }

        .white-card {
            position: relative;
            align-items: center;
            display: flex;
            flex-direction: column; /* Mengatur tata letak fleks menjadi kolom */
            width: 100%;
            width: 1077px;
            height: 527px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            border: 1.5px solid black;
        }

        .blue-card-in-white{
            position: relative;
            align-items: center;
            margin-top: 23px;
            width: 100%;
            width: 977px;
            height: 479px;
            background-color: #D1EBFE;
            border-radius: 1.5px;
            border: 1.9px solid #000; /* Sesuaikan lebar dan warna stroke sesuai kebutuhan */
        }

        .status-info {
            display: flex;
            flex-direction: column;
            height: 100%;
            margin-top: 25px;
            margin-left: 25px;
        }

        .status-info span {
            margin-bottom: 15px;
            font-family: 'Krona One', sans-serif;
            font-size: 15px;
        }

        #nama{
            margin-left: 175px;
        }

        .alamat-span-ya{
            position: relative;
            bottom: 35px;
            margin-left: 247px;
            margin-bottom: -39px;
        }

        #alamat{
            /* margin-left: 163px; */
            margin-left: 0;
            width: 700px; /* Lebar maksimum yang diizinkan */
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: inline-block;
        }

        #jumlahGalon{
            margin-left: 105px;
        }

        #merek{
            margin-left: 175px;
        }

        #totalHarga{
            margin-left: 120px;
        }

        #statusPesanan{
            background-color: #A6D9FF;
            margin-left: 76px;
            border: 0.1px solid #fff; /* Sesuaikan lebar dan warna stroke sesuai kebutuhan */
        }

        #waktuPembuatan{
            margin-left: 51px;
        }

        #waktuUpdate{
            margin-left: 96px;
        }

        .container-teks{
            display: flex;
            align-items: center; /* Untuk memusatkan vertikal */
            justify-content: center;
            margin-left: -25px;
        }

        .container-teks img {
            width: 25px;
            height: 25px;
            margin-left: 21px;
            margin-top: 50px; /* Menambah margin kiri sejauh 10px */
        }

        .teks-di-bawah{
            margin-top: 63px;
            font-size: 15px;
            font-family: 'Krona One', sans-serif;
        }

        .teks-di-bawah-lagi{
            margin-top: 65px;
            margin-left: 9.9px;
            font-size: 15px;
            font-family: 'Krona One', sans-serif;
        }

        .container-konfirmasi-pesanan-user{
            position: relative;
            margin-left: 240px;
            margin-top: 10px;

        }

        /* .background-konfirmasi-pesanan-user{
            font-style: normal;
            font-family: 'Krona One', sans-serif;
            font-size: 13px;
            background-color: #71C3FF;
            width: 364px;
            height: 25px;
        } */

        .background-konfirmasi-pesanan-user h3 {
            font-style: normal;
            font-family: 'Krona One', sans-serif;
            font-size: 15px;
            background-color: #71C3FF;
            width: 364px;
            height: 25px;
            text-align: center; /* Menengahkan horizontal */
            line-height: 25px; /* Menengahkan vertikal */
        }

        .container-checkbox-pesanan-user{
            position: relative;
            margin-left: 630px;
            margin-bottom: -35px;
            bottom: 47px;
            display: inline-block; /* Membuat elemen menjadi inline block */
        }

        .background-checkbox-pesanan-user{
            position: relative;
            color: black;
        }

        .container-checkbox-pesanan-user img {
            color: black;
        }
        
        .hover-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 11.75%;
            height: 94%;
            background-color: rgba(255, 255, 255, 0); /* Transparan saat tidak dihover */
            transition: background-color 0.1s ease; /* Animasi perubahan saat hover */
            z-index: 1; /* Menempatkan di atas gambar */
            cursor: pointer; /* Menambahkan pointer cursor */
        }

        .container-checkbox-pesanan-user:hover .hover-overlay {
            background-color: rgba(255, 255, 255, 0.3); /* Bayangan putih kabur saat dihover */
        }

    </style>

<style>
        .logout-untuk-user-container {
            position: absolute;
            margin-top: 160px;
            margin-left: 19px;
            z-index: 9;
        }

        .logout-button-user {
            font-family: 'Krona One', sans-serif; /* Terapkan font Krona One */
            font-size: 11px;
            width: 95px;
            height: 25px;
            border-radius: 5px;
            border: none;
            display: flex; /* Menyusun ikon dan teks secara horizontal */
            align-items: center; /* Menyelaraskan teks dan ikon di tengah secara vertikal */
            justify-content: center; /* Menyelaraskan secara horizontal */
            padding: 5px 7.5px; /* Padding agar tombol terlihat lebih baik */
        }

        .logout-button-user:hover {
            background-color: #143F6B;
            color: white;
        }
</style>

<style>
        .icon-akun-dan-nama-user-container{
            position: relative;
        }

        ul {
            list-style-type: none;
            margin: 55px 0 0 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: flex-start;
            z-index: 5;
        }

        li span.material-symbols-outlined {
            display: block;
            font-size: 80px;
            color: #FEB139;
        }

        li {
            font-family: 'Krona One', sans-serif; /* Terapkan font Krona One */
            font-size: 7px;
            margin-inline-start: 35%;
            margin-top: -5%;
            margin-bottom: 21px;
            text-align: center;
            font-weight: bold;
            color: #FEB139;
        }
</style>

</head>

<body>

        <div class="card-container">
            <div class="card"></div>
        </div>

        <div class="second-card">
        <span class="status-text" id="statusDepotText">STATUS DEPOT :  </span>
        <div id="statusDepotData"></div>
        </div>

        <div class="icon-akun-dan-nama-user-container">
            <ul>
                <li>
                    <span class="material-symbols-outlined">account_circle</span>
                    <span id="username-display">USER</span>
                </li>
            </ul>
        </div>

        <div class="logout-untuk-user-container">
        <button class="logout-button-user" onclick="confirmLogout()">
            <span class="iconify" data-icon="bx:exit" style="font-size:24px; margin-right: 1px;"></span> LOGOUT
        </button>
        </div>

        <h2 id="daftarAirGalon" class="background-box"><button>STATUS PESANAN</button></h2>

        <h2 id="statusPesananSemua" class="background-box">
        <button onclick="kembaliDariStatusPesanan()">KEMBALI</button>
        </h2>

        <div class="white-card-container">

        <div class="white-card">
        
        <div class="blue-card-in-white">

        <div class="status-info" id="statusInfo">
            <span>Nama: <span id="nama"></span></span>
            <span>Alamat: </span>
            <!-- tambah div lagi agar rapi nilai alamatnya -->
            <div class="alamat-span-ya">
                <span id="alamat"></span>
            </div>
            <span>Jumlah Galon: <span id="jumlahGalon"></span></span>
            <span>Merek: <span id="merek"></span></span>
            <span>Total Harga: <span id="totalHarga"></span></span>
            <span>Status Pesanan: <span id="statusPesanan"></span></span>
            <span>Waktu Pembuatan: <span id="waktuPembuatan"></span></span>
            <span>Waktu Update: <span id="waktuUpdate"></span></span>

            <div class="container-konfirmasi-pesanan-user">
                <div class="background-konfirmasi-pesanan-user">
                    <h3>Konfirmasi Pesanan Telah Sampai</h3>
                </div>
            </div>

            <div class="container-checkbox-pesanan-user">
                <div class="background-checkbox-pesanan-user">
                    <img src="https://i.ibb.co.com/Lrm0fht/logo-checkbox-user.png" alt="logo-checkbox" id="checkbox-image">
                    <div class="hover-overlay"></div>
                </div>
            </div>
            
            <div class="container-teks"><h1 class="teks-di-bawah">Untuk keluhan silahkan hubungi nomor Whatsapp ini :</h1>
            <img src="https://i.ibb.co.com/yVFvdPM/1719983059207.png" alt="logo-wa">
            <h2 class="teks-di-bawah-lagi">0812 2222 2398</h2>
            </div>

        </div>

        </div>

        </div>

        </div>
    
<script>
document.addEventListener("DOMContentLoaded", function () {
    const endpoint = "get_user_session.php"; // Pastikan path benar
    const usernameDisplay = document.getElementById("username-display");

    fetch(endpoint)
        .then(response => {
            if (!response.ok) {
                throw new Error("HTTP error " + response.status);
            }
            return response.json();
        })
        .then(data => {
            console.log("Respons dari server:", data); // Debugging
            if (data.username) {
                usernameDisplay.textContent = data.username; // Ubah teks sesuai username
            } else {
                console.warn("Username tidak ditemukan di respons.");
            }
        })
        .catch(error => {
            console.error("Gagal mengambil data sesi:", error);
        });
});
</script>
    
    <script>
        function confirmLogout() {
            // Menampilkan konfirmasi logout
            let confirmAction = confirm("Apa kamu yakin ingin LOGOUT?");
            if (confirmAction) {
                // Redirect ke logout.php untuk menghapus data user dan sesi
                window.location.href = "logout.php";
            }
        }
    </script>

    <script>

        // Fungsi untuk mendapatkan parameter dari URL
        function getParameterByName(name, url) {
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        }

        // Mendapatkan parameter waktu_pembuatan  dan id dari URL
        var waktuPembuatan = getParameterByName('waktu_pembuatan');
        var idPesanan = getParameterByName('id');

        // Fungsi untuk mengambil data dari server dan memperbarui elemen HTML
function updateStatusPesanan() {
    var xhr = new XMLHttpRequest();

    xhr.open("GET", "ambil_status_pesanan.php?waktu_pembuatan=" + waktuPembuatan + "&id=" + idPesanan, true);

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                var data = JSON.parse(xhr.responseText);

                // Memperbarui elemen HTML dengan data yang diambil
                document.getElementById("nama").innerText = data.nama;
                document.getElementById("alamat").innerText = data.alamat;
                document.getElementById("jumlahGalon").innerText = data.jumlah_galon;
                document.getElementById("merek").innerText = data.merek;
                document.getElementById("totalHarga").innerText = data.total_harga;
                
                // Memeriksa apakah status pesanan adalah "Telah Selesai"
                if (data.status_pesanan === "Telah Selesai") {
                    document.getElementById("statusPesanan").innerText = "Pesanan Telah Sampai";
                } else {
                    document.getElementById("statusPesanan").innerText = data.status_pesanan;
                }
                
                document.getElementById("waktuPembuatan").innerText = data.waktu_pembuatan;
                document.getElementById("waktuUpdate").innerText = data.waktu_update;
            } else {
                console.error("Gagal mengambil data. Kode status: " + xhr.status);
            }
        }
    };

    xhr.send();
}


        // Memanggil fungsi untuk pertama kali
        updateStatusPesanan();

        // Memperbarui data setiap beberapa detik (misalnya, setiap 3000 milidetik)
        setInterval(updateStatusPesanan, 3000);

        function kembaliDariStatusPesanan() {
                // Mengarahkan pengguna kembali ke halaman sebelumnya
                window.history.back();
            }
        
        // Fungsi untuk mengambil data dari server dan memperbarui elemen HTML
        function updateStatusDepot() {
            // Menggunakan XMLHttpRequest untuk membuat permintaan HTTP
            var xhr = new XMLHttpRequest();

            // Mengatur metode, URL, dan mode asinkron
            xhr.open("GET", "ambil_catatan_status_depot.php", true);

            // Menangani perubahan status permintaan
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        // Parsing data JSON dari respons
                        var data = JSON.parse(xhr.responseText);

                        // Memperbarui elemen HTML dengan data yang diambil
                        document.getElementById("statusDepotData").innerHTML = data;
                    } else {
                        console.error("Gagal mengambil data. Kode status: " + xhr.status);
                    }
                }
            };

            // Mengirim permintaan
            xhr.send();
        }

        // Memanggil fungsi untuk pertama kali
        updateStatusDepot();

        // Memperbarui data setiap beberapa detik (misalnya, setiap 3000 milidetik)
        setInterval(updateStatusDepot, 3000);

        // Menambahkan event listener untuk menangani klik pada tombol DAFTAR AIR GALON
        document.getElementById('daftarAirGalon').addEventListener('click', handleDaftarAirGalonClick);
            function handleDaftarAirGalonClick() {
            // Tambahkan logika untuk berpindah ke formulir atau tindakan lainnya
            window.location.href = "index_daftar_air_galon.php";
            // Tambahkan logika lain yang diperlukan
        }

    </script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const checkboxImage = document.getElementById('checkbox-image');
    const containerCheckbox = document.querySelector('.container-checkbox-pesanan-user');

    // Memeriksa apakah pesanan sudah selesai saat halaman dimuat ulang
    if (localStorage.getItem('pesanan_' + idPesanan) === 'selesai') {
        checkboxImage.src = "https://i.ibb.co.com/K0Td1dK/logo-checkbox-user-telah-selesai.png";
    }

    // Event listener untuk mengubah gambar dan status pesanan saat gambar checkbox diklik
    containerCheckbox.addEventListener('click', function() {
        // Memperbarui gambar checkbox
        checkboxImage.src = "https://i.ibb.co.com/K0Td1dK/logo-checkbox-user-telah-selesai.png";

        // Memperbarui status pesanan di server
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "update_status_pesanan.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Periksa respon dari server (jika diperlukan)
                console.log(xhr.responseText);
            }
        };
        // Mengirim data ke server
        xhr.send("id=" + encodeURIComponent(idPesanan) + "&status_pesanan=Telah Selesai");
        
        // Simpan status pesanan ke dalam localStorage
        localStorage.setItem('pesanan_' + idPesanan, 'selesai');
    });
});

</script>

</body>

</html>
