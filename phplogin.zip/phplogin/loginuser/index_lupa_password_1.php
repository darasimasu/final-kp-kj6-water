<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, viewport-fit=cover">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="theme-color" content="#2196f3">
  <title>Lupa Password User 1</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Krona+One:wght@400&display=swap">

  <style>
    body {
      background-image: url('https://i.ibb.co.com/GVRvRXJ/6412173.jpg'); /* Sesuaikan path dengan lokasi gambar */
      /* background-image: url('https://stsci-opo.org/STScI-01H5308GYAN46P3HX4PQ20HP31.png'); */
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
    }

    .custom-card {
    background-color: #D1EBFE;
    border-color: #143F6B;
    border-radius: 5px;
    border-style: inset;
    border-width: 2px;
    width: 350px;
    height: 400px;
    margin-top: 50px;
    margin-left: auto;
    margin-right: auto;
  }
  
  .custom-card-body {
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  
  .button-container {
    display: flex;
    text-align: center;
    height: 9vh;
    justify-content: center;
    align-items: center; /* Tengah secara vertikal */
  }
  
  /* Gaya khusus untuk tombol Register */
  .button-container button:nth-child(2) {
  background-color: #2AAF74; /* Warna latar belakang sesuai dengan desain Anda */
  border: 2px solid #45a049; /* Warna batas sesuai dengan desain Anda */
  width: 100px;
  margin-left: 10px; /* Menambahkan spasi antara tombol Login dan Register */
  transition: background-color 0.3s; /* Efek transisi agar perubahan warna terlihat halus */
  }

  .button-container button:nth-child(2):hover {
  border: 2px solid #fff;
  background-color: #207745; /* Warna hijau tua saat tombol dihover */
  }

  button {
    color: white;
    background-color: #2AAF74;
    border: #D1EBFE;
    width: 100px;
    height: 35px;
    margin-top: 25px;
  }

  .button-container button {
    line-height: 5px; /* Menengahkan tulisan secara vertikal */
  }

  button:hover {
    border: 2px solid #fff;
    background-color: #207745; /* Warna hijau tua saat tombol dihover */
  }

  .form-label {
    margin-bottom: 3px;
    font-family: 'Inter', sans-serif;
    font-size: 13px;
    margin-left: 5px;
  }

  .form-control{
    font-size: 12px;
  }

  .button-container{
    font-family: 'Krona One', sans-serif;
    font-size: 13px;
  }
  </style>

  <style>
  .kata-login-container{
    position: relative;
    margin-bottom: -67px;
  }

  .kata-login-container h1{
    margin-top: 85px;
    font-family: 'Krona One', sans-serif;
    font-size: 26px;
    color: #fff;
    text-align: center;
  }

  .garis-bawah {
    position: relative;
    width: 313px;
    height: 2px;
    background-color: white; /* Warna garis hitam */
    margin: 0px auto 0; /* Jarak atas 5px, tengah otomatis, bawah 0 */
    bottom: 5px;
  }
  </style>

  <style>

  .label-untuk-masukkan-nomor-hp-container{
    cursor: not-allowed;
    position: relative;
    top: 20px;
    bottom: 10px;
    text-align: center;
  }

  .label-untuk-masukkan-nomor-hp h6{
    font-family: 'Krona One', sans-serif;
    font-size: 11px;
  }

  .garis-putih{
    position: relative;
    width: 265px;
    height: 2px;
    background-color: black; /* Warna garis hitam */
    margin: 0px auto 0; /* Jarak atas 5px, tengah otomatis, bawah 0 */
    bottom: 8px;
  }

  </style>

</head>

<body>

<div class="kata-login-container">
    <div>
        <h1>LUPA PASSWORD</h1>
        <div class="garis-bawah"></div>
    </div>
</div>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card custom-card">
                <div class="card-body custom-card-body">
                    <div class="mb-3">
                        <label for="nomor_hp" class="form-label">Nomor Handphone</label>
                        <input type="text" class="form-control" name="nomor_hp" id="nomor_hp" placeholder="Masukkan Nomor Whatsapp Anda" oninput="validateInputNomorHP()" required>
                    </div>
                    <div class="button-container">
                        <button type="button" onclick="requestVerificationCode(event)">Lanjut</button>
                    </div>
                    <div class="label-untuk-masukkan-nomor-hp-container">
                        <div class="label-untuk-masukkan-nomor-hp">
                            <h6>Masukkan Nomor WhatsApp Anda</h6>
                            <div class="garis-putih"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
  function isvalid() {
    var user = document.form.username.value;
    var pass = document.form.password.value;

    if (user === "" && pass === "") {
      alert("Nama dan Kata Sandi tidak boleh kosong!!!");
      return false;
    } else {
      if (user === "") {
        alert("Nama tidak boleh kosong!!!");
        return false;
      }
      if (pass === "") {
        alert("Kata Sandi tidak boleh kosong!!!");
        return false;
      }
    }
    return true;
  }
</script>

<script>
function capitalizeFirstLetter(input) {
            input.value = input.value.toLowerCase().replace(/(?:^|\s)\S/g, function (a) {
                return a.toUpperCase();
            });
        }
</script>

<script>
  function validateInputNomorHP() {
    const nomorHPInput = document.getElementById('nomor_hp');
    const regex = /[^0-9]/g; // Regular expression to match non-numeric characters
    nomorHPInput.value = nomorHPInput.value.replace(regex, ''); // Replace non-numeric characters with an empty string
  }
</script>

<script>
function requestVerificationCode(event) {
    event.preventDefault(); // Mencegah reload halaman

    const nomor_hp = document.getElementById('nomor_hp').value;

    if (!nomor_hp) {
        alert('Nomor handphone tidak boleh kosong!');
        return;
    }

    // Simpan nomor_hp di localStorage
    localStorage.setItem('nomor_hp', nomor_hp);

    // Kirim data ke server
    fetch('send_verification.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nomor_hp })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Kode verifikasi telah dikirim ke nomor WhatsApp Anda.');

            // Setelah kode berhasil dikirim, pindah ke halaman index_lupa_password_2.php
            window.location.href = 'index_lupa_password_2.php';
        } else {
            // Menampilkan pesan error dari PHP di alert
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Terjadi kesalahan. Silakan coba lagi.');
    });
}
</script>

</body>

</html>
