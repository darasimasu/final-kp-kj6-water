<?php
// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "database1";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ambil data yang dikirimkan
$nama_admin = $_POST['nama_admin'] ?? '';
$nomor_hp_admin = $_POST['nomor_hp_admin'] ?? '';
$password_admin = $_POST['password_admin'] ?? '';

// Pastikan nomor HP tidak duplikat
$sql_check_nomor_hp = "SELECT * FROM login WHERE nomor_hp = ?";
$stmt = $conn->prepare($sql_check_nomor_hp);
$stmt->bind_param("s", $nomor_hp_admin);
$stmt->execute();
$result_hp = $stmt->get_result();

// Pastikan username tidak duplikat
$sql_check_username = "SELECT * FROM login WHERE username = ?";
$stmt2 = $conn->prepare($sql_check_username);
$stmt2->bind_param("s", $nama_admin);
$stmt2->execute();
$result_username = $stmt2->get_result();

if ($result_hp->num_rows > 0) {
    // Jika nomor HP sudah ada
    echo "Nomor HP sudah terdaftar!";
} elseif ($result_username->num_rows > 0) {
    // Jika username sudah ada
    echo "Username sudah terdaftar!";
} else {
    // Hash password sebelum disimpan
    $hashed_password = password_hash($password_admin, PASSWORD_DEFAULT);

    // Masukkan data ke dalam tabel
    $sql_insert = "INSERT INTO login (username, password, nomor_hp) VALUES (?, ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("sss", $nama_admin, $hashed_password, $nomor_hp_admin);

    if ($stmt_insert->execute()) {
        echo "Data berhasil disimpan!";
    } else {
        echo "Terjadi kesalahan saat menyimpan data!";
    }
}

// Menutup koneksi
$stmt->close();
$stmt2->close();
$conn->close();
?>
