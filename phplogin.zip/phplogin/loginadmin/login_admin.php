<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db_name = "database1";
    $conn = new mysqli($servername, $username, $password, $db_name);

    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    if(isset($_POST["submit"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];        

        // Query untuk mengambil data user berdasarkan username
        $sql = "SELECT * FROM login WHERE username = '$username'";       
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        $count = mysqli_num_rows($result);

        // Cek apakah username ditemukan dan password cocok dengan hash yang ada
        if($count == 1 && password_verify($password, $row['password'])) {
            // Login berhasil
            header("Location:index_welcome_admin.php");
            exit(); // Tambahkan exit untuk mencegah eksekusi lebih lanjut
        } else {
            // Login gagal
            echo '<script>
                    alert("Login gagal. Username atau password tidak valid!!!");
                    window.location.href = "index_login_admin.php";
                  </script>';
        }
    }
?>
