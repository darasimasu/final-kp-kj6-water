<?php
// Koneksi ke database
$servername = "localhost";
$username = "root"; // Ganti dengan username MySQL Anda
$password = ""; // Ganti dengan password MySQL Anda
$dbname = "database1"; // Nama database yang Anda gunakan

// Membuat koneksi ke MySQL
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengambil data yang dikirimkan oleh frontend
$data = json_decode(file_get_contents('php://input'), true);
$password = $data['password'];
$nomor_hp = $data['nomor_hp'];

// Validasi input
if (!$password || !$nomor_hp) {
    echo json_encode(['success' => false, 'message' => 'Password atau nomor handphone tidak valid!']);
    exit;
}

// Hash password sebelum menyimpannya di database
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

// Cek apakah nomor HP cocok di tabel login
$stmt = $conn->prepare("SELECT * FROM login WHERE nomor_hp = ?");
$stmt->bind_param("s", $nomor_hp);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Update password
    $updateStmt = $conn->prepare("UPDATE login SET password = ? WHERE nomor_hp = ?");
    $updateStmt->bind_param("ss", $hashedPassword, $nomor_hp);
    
    if ($updateStmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Password berhasil diperbarui!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal memperbarui password.']);
    }

    $updateStmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Nomor handphone tidak ditemukan.']);
}

$stmt->close();
$conn->close();
?>
