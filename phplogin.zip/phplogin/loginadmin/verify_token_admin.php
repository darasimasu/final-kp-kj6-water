<?php
// Update the path below to your autoload.php
require_once 'C:/xampp/htdocs/phplogin/vendor/autoload.php'; // Sesuaikan path ke autoload.php Anda
use Twilio\Rest\Client;

// Koneksi ke database (gunakan kredensial database Anda)
$servername = "localhost";
$username = "root"; // Ganti dengan username MySQL Anda
$password = ""; // Ganti dengan password MySQL Anda
$dbname = "database1"; // Nama database yang Anda gunakan

// Membuat koneksi ke MySQL
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengambil data yang dikirimkan oleh frontend
$data = json_decode(file_get_contents('php://input'), true);
$token = $data['token'];
$nomor_hp = $data['nomor_hp'];

// Validasi input
if (!$token || !$nomor_hp) {
    echo json_encode(['success' => false, 'message' => 'Token atau nomor handphone tidak valid!']);
    exit;
}

// Cek apakah token dan nomor HP cocok di tabel verifications_admin
$stmt = $conn->prepare("SELECT * FROM verifications_admin WHERE kode_verifikasi = ? AND nomor_hp = ? AND expires_at > NOW()");
$stmt->bind_param("ss", $token, $nomor_hp); // Binding parameter
$stmt->execute();
$result = $stmt->get_result();

// Jika data ditemukan dan token masih valid
if ($result->num_rows > 0) {
    echo json_encode(['success' => true, 'message' => 'Token verifikasi berhasil!']);
} else {
    echo json_encode(['success' => false, 'message' => 'Token tidak valid atau telah kedaluwarsa.']);
}

$stmt->close();
$conn->close();
?>
