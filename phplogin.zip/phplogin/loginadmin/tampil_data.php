<?php
// Koneksi ke database
$servername = "localhost";
$username = "root"; // Sesuaikan dengan username database Anda
$password = ""; // Sesuaikan dengan password database Anda
$dbname = "database1";

$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query untuk mengambil data dari tabel login, termasuk email
$sql = "SELECT id, username, nomor_hp, password, waktu_pembuatan FROM login";
$result = $conn->query($sql);

// Menyimpan data dalam array untuk digunakan di HTML
$data = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
} else {
    $data = null; // Jika tidak ada data
}

// Tutup koneksi
$conn->close();

// Mengembalikan data dalam format JSON
echo json_encode($data);
?>
