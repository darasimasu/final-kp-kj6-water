<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, viewport-fit=cover">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="theme-color" content="#2196f3">
  <title>Lupa Password User 4</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Krona+One:wght@400&display=swap">

  <style>
    body {
      background-image: url('https://i.ibb.co.com/31DH6Lp/travel-06.jpg'); /* Sesuaikan path dengan lokasi gambar */
      /* background-image: url('https://stsci-opo.org/STScI-01H5308GYAN46P3HX4PQ20HP31.png'); */
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
    }

    .custom-card {
    background-color: #D1EBFE;
    border-color: #143F6B;
    border-radius: 5px;
    border-style: inset;
    border-width: 2px;
    width: 350px;
    height: 400px;
    margin-top: 50px;
    margin-left: auto;
    margin-right: auto;
  }
  
  .custom-card-body {
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  
  .button-container {
    display: flex;
    text-align: center;
    height: 12vh;
    justify-content: center;
    align-items: center; /* Tengah secara vertikal */
  }
  
  /* Gaya khusus untuk tombol Register */
  .button-container button:nth-child(2) {
  background-color: #2AAF74; /* Warna latar belakang sesuai dengan desain Anda */
  border: 2px solid #45a049; /* Warna batas sesuai dengan desain Anda */
  width: 100px;
  margin-left: 10px; /* Menambahkan spasi antara tombol Login dan Register */
  transition: background-color 0.3s; /* Efek transisi agar perubahan warna terlihat halus */
  }

  .button-container button:nth-child(2):hover {
  border: 2px solid #fff;
  background-color: #207745; /* Warna hijau tua saat tombol dihover */
  }

  button {
    color: white;
    background-color: #2AAF74;
    border: #D1EBFE;
    width: 100px;
    height: 35px;
    margin-top: 25px;
  }

  .button-container button {
    line-height: 5px; /* Menengahkan tulisan secara vertikal */
  }

  button:hover {
    border: 2px solid #fff;
    background-color: #207745; /* Warna hijau tua saat tombol dihover */
  }

  .form-label {
    margin-bottom: 3px;
    font-family: 'Inter', sans-serif;
    font-size: 13px;
    margin-left: 5px;
  }

  .form-control{
    font-size: 12px;
  }

  .button-container{
    font-family: 'Krona One', sans-serif;
    font-size: 13px;
  }
  </style>

  <style>
  .kata-login-container{
    position: relative;
    margin-bottom: -67px;
  }

  .kata-login-container h1{
    margin-top: 85px;
    font-family: 'Krona One', sans-serif;
    font-size: 26px;
    color: #000;
    text-align: center;
  }

  .garis-bawah {
    position: relative;
    width: 313px;
    height: 2px;
    background-color: black; /* Warna garis hitam */
    margin: 0px auto 0; /* Jarak atas 5px, tengah otomatis, bawah 0 */
    bottom: 5px;
  }
  </style>

  <style>

  .label-untuk-masukkan-email-container{
    cursor: not-allowed;
    position: relative;
    top: 20px;
    bottom: 10px;
    text-align: center;
  }

  .label-untuk-masukkan-email h6{
    font-family: 'Inter', sans-serif;
    font-size: 13px;
  }

  </style>

</head>

<body>

  <div class="kata-login-container">
    <div>
      <h1>LUPA PASSWORD</h1>
      <div class="garis-bawah"></div>
    </div>
  </div>

  <div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card custom-card">
                <div class="card-body custom-card-body">
                    <div class="label-untuk-masukkan-email-container">
                        <div class="label-untuk-masukkan-email">
                            <h6>Selamat! Anda telah berhasil mereset</br>password Anda. Silahkan kembali ke</br>halaman Login untuk login ulang.</h6>
                            <div class="garis-putih"></div>
                        </div>
                    </div>
                    <div class="button-container">
                        <button type="button" onclick="redirectToLogin()">Lanjut</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>

<script>
    function redirectToLogin() {
        window.location.href = "index_login_admin.php";
    }
</script>

</body>

</html>
